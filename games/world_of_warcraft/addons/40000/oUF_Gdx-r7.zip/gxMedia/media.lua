gxMedia = {
	auraFont = [=[Interface\Addons\gxMedia\media\squares.ttf]=],
	bgFile = [=[Interface\ChatFrame\ChatFrameBackground]=],
	buttonOverlay = [=[Interface\Addons\gxMedia\media\buttonoverlay]=],
	edgeFile = [=[Interface\Addons\gxMedia\media\backdropedge]=],
	font = [=[Interface\Addons\gxMedia\media\Russel Square LT.ttf]=],
	glow = [=[Interface\Addons\gxMedia\media\glow]=],
	statusBar = [=[Interface\AddOns\gxMedia\media\statusbar]=],
	symbolFont = [=[Interface\Addons\gxMedia\media\PIZZADUDEBULLETS.ttf]=]
}